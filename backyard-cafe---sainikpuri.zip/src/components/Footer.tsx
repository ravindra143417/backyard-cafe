import { motion } from "motion/react";
import { Coffee, Instagram, MapPin, Phone, MessageCircle } from "lucide-react";

export default function Footer() {
  return (
    <footer id="footer" className="bg-[#2D241E] text-white pt-24 pb-12 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16 px-4 py-8 bg-white/5 rounded-[40px] border border-white/10">
          <div className="space-y-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-vibrant-amber rounded-xl flex items-center justify-center text-white font-black">
                B
              </div>
              <span className="text-xl font-black italic">Backyard Cafe</span>
            </div>
            <p className="text-white/60 font-medium leading-relaxed text-sm">
              Sainikpuri's favorite sanctuary. Handcrafted with passion, served with love.
            </p>
            <div className="flex gap-4">
              <a href="#" className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-vibrant-amber transition-colors">
                <Instagram size={18} />
              </a>
              <a href="https://wa.me/911234567890" className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-vibrant-wa transition-colors text-white">
                <MessageCircle size={18} />
              </a>
            </div>
          </div>

          <div className="space-y-6">
            <h4 className="font-black uppercase tracking-[0.2em] text-xs text-vibrant-amber">Quick Links</h4>
            <ul className="space-y-4 font-medium text-white/70 text-sm">
              <li><a href="#home" className="hover:text-vibrant-amber transition-colors">The Entrance</a></li>
              <li><a href="#menu" className="hover:text-vibrant-amber transition-colors">The Menu</a></li>
              <li><a href="#about" className="hover:text-vibrant-amber transition-colors">Context</a></li>
              <li><a href="#" className="hover:text-vibrant-amber transition-colors">Launch Website</a></li>
            </ul>
          </div>

          <div className="space-y-6">
            <h4 className="font-black uppercase tracking-[0.2em] text-xs text-vibrant-amber">Opening Hours</h4>
            <ul className="space-y-4 font-medium text-white/70 text-sm">
              <li className="flex justify-between"><span>Mon - Thu</span> <span>8 AM - 10 PM</span></li>
              <li className="flex justify-between text-vibrant-orange"><span>Fri - Sun</span> <span>8 AM - 11 PM</span></li>
              <li className="pt-2 text-xs italic opacity-40 font-bold uppercase tracking-widest">Status: Plan Ready</li>
            </ul>
          </div>

          <div className="space-y-6">
            <h4 className="font-black uppercase tracking-[0.2em] text-xs text-vibrant-amber">Location</h4>
            <div className="flex gap-3 text-white/70">
              <MapPin className="shrink-0 text-vibrant-amber" size={18} />
              <p className="text-sm font-medium leading-relaxed">
                Plot 14, Defence Colony, <br />
                Sainikpuri, Hyderabad, <br />
                Telangana 500094
              </p>
            </div>
          </div>
        </div>

        <div className="mt-8 flex flex-col md:flex-row justify-between items-center gap-6 pt-8 border-t border-white/5">
          <div className="flex items-center gap-6 italic text-white/40 text-xs font-bold uppercase tracking-widest">
            <span>SEO Optimized</span>
            <span>Mobile First</span>
          </div>
          <motion.a 
            href="https://wa.me/911234567890"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="flex items-center gap-3 px-10 py-5 bg-vibrant-wa text-white rounded-[24px] font-black tracking-widest uppercase text-sm shadow-2xl shadow-vibrant-wa/20"
          >
            <MessageCircle size={20} />
            The Hot-Line
          </motion.a>
        </div>
      </div>
    </footer>
  );
}
