import { motion } from "motion/react";

export default function About() {
  return (
    <section id="about" className="py-24 px-6 bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col lg:flex-row items-center gap-20">
          <div className="flex-1 order-2 lg:order-1">
            <div className="grid grid-cols-2 gap-6">
              <motion.div
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="space-y-6"
              >
                <img 
                  src="https://images.unsplash.com/photo-1442512595331-e89e73853f31?q=80&w=2070&auto=format&fit=crop" 
                  alt="Coffee Beans" 
                  className="rounded-[40px] w-full aspect-[4/5] object-cover shadow-2xl translate-y-12"
                  referrerPolicy="no-referrer"
                />
                <div className="clay-card p-8 flex flex-col items-center justify-center text-center bg-amber-50">
                  <span className="text-4xl font-black text-vibrant-amber">100%</span>
                  <span className="text-xs font-black tracking-widest uppercase text-vibrant-text/60">Arabica Beans</span>
                </div>
              </motion.div>
              <motion.div
                initial={{ opacity: 0, y: -40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="space-y-6"
              >
                <div className="clay-card p-8 flex flex-col items-center justify-center text-center bg-vibrant-green text-white">
                  <span className="text-4xl font-black">⭐️⭐️⭐️⭐️⭐️</span>
                  <span className="text-xs font-black tracking-widest uppercase opacity-80 mt-2">Live Google Feed</span>
                </div>
                <img 
                  src="https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?q=80&w=2070&auto=format&fit=crop" 
                  alt="Cafe Atmosphere" 
                  className="rounded-[40px] w-full aspect-[4/5] object-cover shadow-2xl border-4 border-[#FAF7F2]"
                  referrerPolicy="no-referrer"
                />
              </motion.div>
            </div>
          </div>

          <div className="flex-1 order-1 lg:order-2">
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <span className="section-tag">Why This Stack?</span>
              <h3 className="text-5xl font-black leading-tight text-vibrant-text mb-8 tracking-tight">
                Google Site Studio & <br />
                <span className="text-vibrant-green">Gemini 2.0 Pro</span>
              </h3>
              <div className="space-y-6 text-lg text-vibrant-text/70 font-medium leading-relaxed">
                <p>
                  Optimized for Google Search — pages load fast, are mobile-first by default, and connect natively to Google Analytics and Search Console.
                </p>
                <div className="p-4 bg-vibrant-bg rounded-2xl border border-vibrant-border italic">
                  "The best outdoor seating in Sainikpuri. Great coffee!"
                </div>
                <p>
                  Generates all your copy in a warm, locally-relevant tone so you're not starting from scratch. Perfect for your Hyderabad audience.
                </p>
              </div>
              
              <div className="mt-12 p-6 bg-vibrant-orange rounded-[32px] text-white flex items-center justify-between shadow-xl shadow-vibrant-orange/20">
                <div>
                  <h4 className="text-2xl font-black">Plan Ready</h4>
                  <p className="text-sm font-bold uppercase tracking-widest opacity-80">Sync Analytics</p>
                </div>
                <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center text-2xl">
                  🚀
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}
