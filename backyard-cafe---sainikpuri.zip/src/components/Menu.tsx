import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ExternalLink, ShoppingBag } from "lucide-react";

type MenuItem = {
  name: string;
  price: string;
  description: string;
  tag?: string;
};

type MenuCategory = {
  title: string;
  items: MenuItem[];
};

const MENU_DATA: MenuCategory[] = [
  {
    title: "Signature Brews",
    items: [
      { name: "Sainikpuri Special Latte", price: "₹240", description: "Our secret house-blend with notes of caramel and hazelnut.", tag: "Popular" },
      { name: "Lavender Cold Brew", price: "₹220", description: "12-hour steeped cold brew infused with organic floral lavender." },
      { name: "Vietnamese Phin", price: "₹260", description: "Traditional slow-drip coffee with condensed milk.", tag: "Chef's Choice" },
      { name: "Peppermint Mocha", price: "₹250", description: "Dark chocolate meets refreshing mint in a velvety milk base." },
    ]
  },
  {
    title: "Artisanal Bites",
    items: [
      { name: "Avocado Sourdough Toast", price: "₹380", description: "Chilled avocado mash on house-made sourdough with chilli flakes.", tag: "Vegan" },
      { name: "Truffle Mushroom Melt", price: "₹320", description: "Sautéed wild mushrooms with stringy mozzarella and truffle oil." },
      { name: "Backyard Garden Salad", price: "₹290", description: "Fresh greens, roasted nuts, and balsamic glaze from our local garden." },
      { name: "Spicy Paneer Cubano", price: "₹340", description: "A local twist on the classic Cuban pressed sandwich.", tag: "Spicy" },
    ]
  },
  {
    title: "Sweet Cravings",
    items: [
      { name: "Baked Cheesecake", price: "₹310", description: "Classic New York style with a blueberry compote swipe.", tag: "Must Try" },
      { name: "Tiramisu Jar", price: "₹280", description: "Espresso soaked ladyfingers layered with fresh mascarpone." },
      { name: "Gooey Brownie Skillet", price: "₹250", description: "Warm chocolate brownie served with vanilla bean ice cream." },
    ]
  }
];

export default function Menu() {
  const [activeCategory, setActiveCategory] = useState(0);

  return (
    <section id="menu" className="py-24 px-6 bg-vibrant-bg">
      <div className="max-w-4xl mx-auto text-center mb-16">
        <span className="section-tag">Dine-in & Delivery</span>
        <h3 className="text-5xl font-black text-vibrant-text tracking-tight uppercase">The Menu</h3>
      </div>

      <div className="max-w-4xl mx-auto">
        {/* Category Tabs */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {MENU_DATA.map((cat, i) => (
            <button
              key={cat.title}
              onClick={() => setActiveCategory(i)}
              className={`px-8 py-3 rounded-2xl text-xs font-black uppercase tracking-widest transition-all ${
                activeCategory === i 
                ? i % 2 === 0 ? "bg-vibrant-orange text-white shadow-xl shadow-vibrant-orange/20" : "bg-vibrant-green text-white shadow-xl shadow-vibrant-green/20"
                : "bg-white text-vibrant-text hover:bg-vibrant-border/30 border border-vibrant-border"
              }`}
            >
              {cat.title}
            </button>
          ))}
        </div>

        {/* Menu Items */}
        <div className="min-h-[400px]">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeCategory}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.4 }}
              className="grid grid-cols-1 md:grid-cols-2 gap-6"
            >
              {MENU_DATA[activeCategory].items.map((item) => (
                <div key={item.name} className="clay-card p-8 hover:-translate-y-1 transition-all">
                  <div className="flex justify-between items-start mb-2">
                    <h4 className="text-xl font-black text-vibrant-text leading-tight">{item.name}</h4>
                    <span className="text-vibrant-amber font-black">{item.price}</span>
                  </div>
                  <p className="text-vibrant-text/60 font-medium text-sm mb-4 leading-relaxed">
                    {item.description}
                  </p>
                  {item.tag && (
                    <span className="inline-block px-3 py-1 bg-vibrant-bg text-vibrant-text text-[10px] font-black tracking-[0.2em] uppercase rounded-lg border border-vibrant-border">
                      {item.tag}
                    </span>
                  )}
                </div>
              ))}
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Delivery Links */}
        <div className="mt-20 flex flex-col items-center gap-8">
          <div className="flex flex-col sm:flex-row items-center gap-6">
            <a 
              href="#"
              className="flex items-center gap-3 px-8 py-4 bg-white border-2 border-vibrant-border text-vibrant-text rounded-[24px] font-black text-xs uppercase tracking-widest hover:border-vibrant-amber transition-all shadow-sm"
            >
              <div className="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center text-red-600">Z</div>
              Zomato
            </a>
            <a 
              href="#"
              className="flex items-center gap-3 px-8 py-4 bg-white border-2 border-vibrant-border text-vibrant-text rounded-[24px] font-black text-xs uppercase tracking-widest hover:border-vibrant-orange transition-all shadow-sm"
            >
              <div className="w-8 h-8 bg-orange-100 rounded-full flex items-center justify-center text-orange-600">S</div>
              Swiggy
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
