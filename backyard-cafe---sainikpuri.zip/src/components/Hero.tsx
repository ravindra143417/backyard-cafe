import { motion } from "motion/react";
import { ArrowRight } from "lucide-react";

export default function Hero() {
  return (
    <section id="home" className="relative pt-32 pb-20 px-6 overflow-hidden bg-vibrant-bg">
      <div className="max-w-7xl mx-auto flex flex-col lg:flex-row items-center gap-16">
        <div className="flex-1 text-center lg:text-left">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <span className="section-tag">
              Neighborhood Vibes
            </span>
            <h1 className="text-6xl md:text-8xl font-black leading-[0.9] text-vibrant-text mb-8 tracking-tighter">
              Your Daily <br />
              <span className="text-vibrant-orange italic">Escape.</span>
            </h1>
            <p className="text-xl md:text-2xl text-vibrant-text/70 max-w-xl mx-auto lg:mx-0 mb-10 leading-relaxed font-medium">
              Experience artisanal coffee, handcrafted desserts, and a sanctuary where the city fades away in the heart of Sainikpuri.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4">
              <motion.a
                href="#menu"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="bg-vibrant-orange text-white px-8 py-4 rounded-3xl text-lg font-black tracking-widest uppercase group flex items-center gap-2 shadow-xl shadow-vibrant-orange/20"
              >
                Explore Menu
                <ArrowRight className="group-hover:translate-x-1 transition-transform" />
              </motion.a>
              <a 
                href="#about"
                className="px-8 py-4 text-vibrant-text font-black tracking-widest uppercase transition-colors hover:text-vibrant-amber"
              >
                The Entrance
              </a>
            </div>
          </motion.div>
        </div>

        <div className="flex-1 relative">
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="grid grid-cols-2 gap-6 relative z-10"
          >
            <img 
              src="https://images.unsplash.com/photo-1554118811-1e0d58224f24?q=80&w=2047&auto=format&fit=crop" 
              alt="Cafe Interior" 
              className="rounded-[40px] mt-12 shadow-2xl border-4 border-white"
              referrerPolicy="no-referrer"
            />
            <img 
              src="https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?q=80&w=2078&auto=format&fit=crop" 
              alt="Latte Art" 
              className="rounded-[40px] shadow-2xl border-4 border-white"
              referrerPolicy="no-referrer"
            />
          </motion.div>
          
          {/* Abstract blobs */}
          <div className="absolute -top-10 -right-10 w-64 h-64 bg-vibrant-orange/10 blur-3xl rounded-full" />
          <div className="absolute -bottom-10 -left-10 w-64 h-64 bg-vibrant-green/5 blur-3xl rounded-full" />
        </div>
      </div>
    </section>
  );
}
