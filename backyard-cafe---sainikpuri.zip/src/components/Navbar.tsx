import { motion } from "motion/react";
import { Coffee, Menu as MenuIcon, X } from "lucide-react";
import { useState } from "react";

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);

  const navLinks = [
    { name: "Home", href: "#home" },
    { name: "Menu", href: "#menu" },
    { name: "About", href: "#about" },
    { name: "Location", href: "#footer" },
  ];

  return (
    <nav className="fixed top-0 left-0 w-full z-50 bg-white/80 backdrop-blur-md border-b border-vibrant-border">
      <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="flex items-center gap-3"
        >
          <div className="w-10 h-10 bg-vibrant-amber rounded-xl flex items-center justify-center text-white font-black text-xl shadow-lg shadow-vibrant-amber/20">
            B
          </div>
          <h1 className="text-xl font-black tracking-tight italic text-vibrant-text">
            Backyard Cafe <span className="text-vibrant-amber font-normal not-italic">— Sainikpuri</span>
          </h1>
        </motion.div>

        {/* Desktop Links */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link, i) => (
            <motion.a
              key={link.name}
              href={link.href}
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="text-xs font-black uppercase tracking-[0.2em] text-vibrant-text/60 hover:text-vibrant-amber transition-colors"
            >
              {link.name}
            </motion.a>
          ))}
          <motion.a
            href="https://wa.me/911234567890"
            target="_blank"
            rel="no-referrer"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="bg-vibrant-green text-white px-6 py-2.5 rounded-full text-xs font-black uppercase tracking-widest hover:bg-vibrant-green/90 transition-all shadow-lg shadow-vibrant-green/20"
          >
            Launch Website
          </motion.a>
        </div>

        {/* Mobile Toggle */}
        <button className="md:hidden text-vibrant-text" onClick={() => setIsOpen(!isOpen)}>
          {isOpen ? <X /> : <MenuIcon />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <motion.div 
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: "auto" }}
          className="md:hidden bg-white border-b border-vibrant-border px-6 py-8"
        >
          <div className="flex flex-col gap-6">
            {navLinks.map((link) => (
              <a 
                key={link.name}
                href={link.href} 
                onClick={() => setIsOpen(false)}
                className="text-2xl font-black text-vibrant-text"
              >
                {link.name}
              </a>
            ))}
            <a 
              href="https://wa.me/911234567890"
              target="_blank"
              rel="no-referrer"
              className="bg-vibrant-green text-white px-6 py-4 rounded-2xl text-center font-black tracking-widest uppercase text-sm shadow-xl shadow-vibrant-green/20"
            >
              Reserve via WhatsApp
            </a>
          </div>
        </motion.div>
      )}
    </nav>
  );
}
